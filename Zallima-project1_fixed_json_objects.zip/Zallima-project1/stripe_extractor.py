import os
import time
import logging
import stripe
from dotenv import load_dotenv
from validator import validate_all_data
from data_saver import save_stripe_data

load_dotenv()

STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY")

if not STRIPE_SECRET_KEY:
    raise ValueError("STRIPE_SECRET_KEY not found in .env file")

stripe.api_key = STRIPE_SECRET_KEY


# -----------------------------
# Logging Configuration
# -----------------------------

LOG_DIR = "logs"
LOG_FILE = os.path.join(LOG_DIR, "stripe.log")

os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)


# -----------------------------
# Customers
# -----------------------------

def get_all_customers():

    try:
        logger.info("Starting customer extraction")

        customers = stripe.Customer.list(
            limit=100
        )

        all_customers = list(
            customers.auto_paging_iter()
        )

        logger.info(
            f"Customers retrieved: {len(all_customers)}"
        )

        print(
            f"Customers retrieved: {len(all_customers)}"
        )

        return all_customers

    except stripe.error.RateLimitError:
        logger.warning(
            "Stripe rate limit reached. Retrying..."
        )

        print(
            "Stripe rate limit reached. Retrying..."
        )

        time.sleep(2)

        return get_all_customers()

    except stripe.error.StripeError as e:

        logger.error(
            f"Stripe customer extraction error: {e}"
        )

        print(
            f"Stripe error: {e}"
        )

        return []


# -----------------------------
# Payment Intents
# -----------------------------

def get_all_payment_intents():

    try:
        logger.info(
            "Starting payment intent extraction"
        )

        payment_intents = stripe.PaymentIntent.list(
            limit=100
        )

        all_payment_intents = list(
            payment_intents.auto_paging_iter()
        )

        logger.info(
            f"Payment Intents retrieved: "
            f"{len(all_payment_intents)}"
        )

        print(
            f"Payment Intents retrieved: "
            f"{len(all_payment_intents)}"
        )

        return all_payment_intents

    except stripe.error.RateLimitError:

        logger.warning(
            "Stripe rate limit reached. Retrying..."
        )

        print(
            "Stripe rate limit reached. Retrying..."
        )

        time.sleep(2)

        return get_all_payment_intents()

    except stripe.error.StripeError as e:

        logger.error(
            f"Stripe payment intent extraction error: {e}"
        )

        print(
            f"Stripe error: {e}"
        )

        return []


# -----------------------------
# Charges
# -----------------------------

def get_all_charges():

    try:
        logger.info(
            "Starting charge extraction"
        )

        charges = stripe.Charge.list(
            limit=100
        )

        all_charges = list(
            charges.auto_paging_iter()
        )

        logger.info(
            f"Charges retrieved: {len(all_charges)}"
        )

        print(
            f"Charges retrieved: {len(all_charges)}"
        )

        return all_charges

    except stripe.error.RateLimitError:

        logger.warning(
            "Stripe rate limit reached. Retrying..."
        )

        print(
            "Stripe rate limit reached. Retrying..."
        )

        time.sleep(2)

        return get_all_charges()

    except stripe.error.StripeError as e:

        logger.error(
            f"Stripe charge extraction error: {e}"
        )

        print(
            f"Stripe error: {e}"
        )

        return []


# -----------------------------
# Main Test
# -----------------------------

def test_stripe_connection():

    logger.info(
        "========== Stripe extraction started =========="
    )

    print("Testing Stripe connection...")

    customers = get_all_customers()

    payment_intents = get_all_payment_intents()

    charges = get_all_charges()
    customers,payment_intents,charges=validate_all_data(customers,payment_intents,charges)
    save_stripe_data(customers,payment_intents,charges)

    print("\n========== STRIPE SUMMARY ==========")

    print(
        f"Customers: {len(customers)}"
    )

    print(
        f"Payment Intents: {len(payment_intents)}"
    )

    print(
        f"Charges: {len(charges)}"
    )

    print(
        "===================================="
    )

    logger.info(
        "Stripe extraction completed successfully"
    )


if __name__ == "__main__":
    test_stripe_connection()