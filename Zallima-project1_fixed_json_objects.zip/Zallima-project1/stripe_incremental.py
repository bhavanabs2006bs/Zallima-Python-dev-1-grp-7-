import os
import json
from datetime import datetime, timezone

import stripe
from dotenv import load_dotenv

load_dotenv()

STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY")

if not STRIPE_SECRET_KEY:
    raise ValueError("STRIPE_SECRET_KEY not found in .env file")

stripe.api_key = STRIPE_SECRET_KEY

STATE_FILE = "last_sync.json"


def load_last_sync():
    """Read the timestamp of the last successful sync."""

    if not os.path.exists(STATE_FILE):
        return 0

    with open(STATE_FILE, "r") as file:
        data = json.load(file)

    return data.get("last_sync", 0)


def save_last_sync(timestamp):
    """Save the latest successful sync timestamp."""

    with open(STATE_FILE, "w") as file:
        json.dump(
            {
                "last_sync": timestamp
            },
            file,
            indent=4
        )


def get_incremental_payment_intents():
    """Retrieve only Payment Intents created after the last sync."""

    last_sync = load_last_sync()

    print(f"Last sync timestamp: {last_sync}")

    try:
        payment_intents = stripe.PaymentIntent.list(
            created={
                "gt": last_sync
            },
            limit=100
        )

        new_payment_intents = list(
            payment_intents.auto_paging_iter()
        )

        print(
            f"New Payment Intents retrieved: "
            f"{len(new_payment_intents)}"
        )

        return new_payment_intents

    except stripe.error.StripeError as e:
        print(f"Stripe error: {e}")
        return []


def incremental_sync():
    """Run incremental Stripe synchronization."""

    print("Starting incremental Stripe sync...")

    current_timestamp = int(
        datetime.now(timezone.utc).timestamp()
    )

    payment_intents = get_incremental_payment_intents()

    # Save timestamp only after successful extraction
    save_last_sync(current_timestamp)

    print("\n========== INCREMENTAL SYNC ==========")
    print(
        f"New Payment Intents: "
        f"{len(payment_intents)}"
    )
    print("Sync completed successfully.")
    print("======================================")


if __name__ == "__main__":
    incremental_sync()