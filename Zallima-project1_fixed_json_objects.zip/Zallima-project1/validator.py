import logging

logger = logging.getLogger(__name__)


def validate_customer(customer):
    """Validate a Stripe customer."""

    required_fields = ["id", "created"]

    for field in required_fields:
        if field not in customer:
            logger.error(
                f"Customer validation failed: missing {field}"
            )
            return False

    return True


def validate_payment_intent(payment_intent):
    """Validate a Stripe Payment Intent."""

    required_fields = [
        "id",
        "amount",
        "currency",
        "status",
        "created"
    ]

    for field in required_fields:
        if field not in payment_intent:
            logger.error(
                f"Payment Intent validation failed: missing {field}"
            )
            return False

    if payment_intent["amount"] < 0:
        logger.error(
            f"Invalid Payment Intent amount: "
            f"{payment_intent['amount']}"
        )
        return False

    return True


def validate_charge(charge):
    """Validate a Stripe charge."""

    required_fields = [
        "id",
        "amount",
        "currency",
        "status",
        "created"
    ]

    for field in required_fields:
        if field not in charge:
            logger.error(
                f"Charge validation failed: missing {field}"
            )
            return False

    if charge["amount"] < 0:
        logger.error(
            f"Invalid charge amount: {charge['amount']}"
        )
        return False

    return True


def validate_all_data(
    customers,
    payment_intents,
    charges
):
    """Validate all extracted Stripe data."""

    valid_customers = [
        customer
        for customer in customers
        if validate_customer(customer)
    ]

    valid_payment_intents = [
        payment_intent
        for payment_intent in payment_intents
        if validate_payment_intent(payment_intent)
    ]

    valid_charges = [
        charge
        for charge in charges
        if validate_charge(charge)
    ]

    print("\n========== VALIDATION ==========")

    print(
        f"Valid Customers: "
        f"{len(valid_customers)}/{len(customers)}"
    )

    print(
        f"Valid Payment Intents: "
        f"{len(valid_payment_intents)}/{len(payment_intents)}"
    )

    print(
        f"Valid Charges: "
        f"{len(valid_charges)}/{len(charges)}"
    )

    print("================================")

    return (
        valid_customers,
        valid_payment_intents,
        valid_charges
    )