import json
import os


DATA_DIR = "data"


def convert_to_json_object(item):
    """Convert Stripe objects into normal Python dictionaries/lists."""

    if hasattr(item, "to_dict_recursive"):
        return item.to_dict_recursive()

    if isinstance(item, dict):
        return {
            key: convert_to_json_object(value)
            for key, value in item.items()
        }

    if isinstance(item, list):
        return [
            convert_to_json_object(value)
            for value in item
        ]

    return item


def save_to_json(data, filename):
    """Save data as real JSON objects, not JSON strings."""

    os.makedirs(DATA_DIR, exist_ok=True)

    file_path = os.path.join(DATA_DIR, filename)

    json_data = [
        convert_to_json_object(item)
        for item in data
    ]

    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(
            json_data,
            file,
            indent=4,
            ensure_ascii=False
        )

    print(f"Saved {len(json_data)} records to {file_path}")


def save_stripe_data(
    customers,
    payment_intents,
    charges
):
    """Save all Stripe data."""

    save_to_json(
        customers,
        "customers.json"
    )

    save_to_json(
        payment_intents,
        "payment_intents.json"
    )

    save_to_json(
        charges,
        "charges.json"
    )

    print("\nStripe data saved successfully!")
