from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import json
import os

app = FastAPI(
    title="Stripe Analytics API",
    description="API for Stripe payment analytics",
    version="1.0.0"
)

# Allow dashboard/frontend to access the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


DATA_DIR = "data"


def load_json(filename):
    """Load JSON data from the data folder."""

    file_path = os.path.join(DATA_DIR, filename)

    if not os.path.exists(file_path):
        return []

    with open(file_path, "r", encoding="utf-8") as file:
        return json.load(file)


@app.get("/")
def home():
    return {
        "message": "Stripe Analytics API is running",
        "status": "success"
    }


@app.get("/customers")
def customers():
    return load_json("customers.json")


@app.get("/payment-intents")
def payment_intents():
    return load_json("payment_intents.json")


@app.get("/charges")
def charges():
    return load_json("charges.json")


@app.get("/summary")
def summary():

    customers_data = load_json("customers.json")
    payment_intents_data = load_json("payment_intents.json")
    charges_data = load_json("charges.json")

    return {
        "customers": len(customers_data),
        "payment_intents": len(payment_intents_data),
        "charges": len(charges_data)
    }